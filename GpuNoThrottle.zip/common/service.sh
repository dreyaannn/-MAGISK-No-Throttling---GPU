sleep 14

# Gpu tune DIR
PATH="/sys/class/kgsl/kgsl-3d0"

# Start
echo 0 > $PATH/bus_split
#
sleep 1
#
echo 1 > $PATH/force_bus_on
#
sleep 1
#
echo 1 > $PATH/force_rail_on
#
sleep 1
#
echo 1 > $PATH/force_clk_on
#
sleep 1
#
echo 1 > $PATH/force_no_nap
#
sleep 1
#
echo 1000000 > $PATH/idle_timer
# End
